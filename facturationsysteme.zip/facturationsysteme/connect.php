<?php
$con = mysqli_connect("localhost","root","","facturationsysteme");
if (mysqli_connect_errno())
  {
  echo "Connexion échouée: " . mysqli_connect_error();
  }
?>


-- Database: `facturationsysteme`
CREATE TABLE `invoice_order` (
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_receiver_name` varchar(255) NOT NULL,
  `order_receiver_address` varchar(255) NOT NULL,
  `order_total_before_tax` varchar(255) NOT NULL,
  `order_total_tax` varchar(255) NOT NULL,
  `order_tax_per` varchar(255) NOT NULL,
  `order_total_after_tax` varchar(255) NOT NULL,
  `order_amount_paid` varchar(255) NOT NULL,
  `order_total_amount_due` varchar(255) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Données table `invoice_order`
--

INSERT INTO `invoice_order` (`user_id`, `order_id`, `order_receiver_name`, `order_receiver_address`, `order_total_before_tax`, `order_total_tax`, `order_tax_per`, `order_total_after_tax`, `order_amount_paid`, `order_total_amount_due`, `order_date`, `note`) VALUES
(1, 3, 'Brady', '225 Rue de la victoire', '198', '0', '0', '198', '198', '0', '2022-07-11 23:30:54', 'test 1'),
(2, 4, 'Saca', 'Rue Jean Jaures 12', '2036', '142.52', '7', '2178.52', '2178.52', '0', '2022-07-12 00:01:07', 'No test!!!'),
(3, 5, 'Cola Company', 'Callewaertstraat 78', '4116', '288.12', '7', '4404.12', '4404.12', '0', '2022-07-12 00:06:31', 'plus tardt!!');

ALTER TABLE `invoice_order`
    ADD PRIMARY KEY (`order_id`);
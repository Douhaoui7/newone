-- Database: `facturationsysteme`


CREATE TABLE `invoice_order_item` (
  `order_id` int(11) NOT NULL,
  `item_code` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `order_item_quantity` varchar(255) NOT NULL,
  `order_item_price` varchar(255) NOT NULL,
  `order_item_final_amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `invoice_order_item`
--

INSERT INTO `invoice_order_item` (`order_id`, `item_code`, `item_name`, `order_item_quantity`, `order_item_price`, `order_item_final_amount`) VALUES
(0, '101', 'Jupe', '52', '110', '5720'),
(1, '102', 'Pantalon', '22', '52', '1144'),
(2, '101', 'Chemise', '115', '12', '1380'),
(3, '108', 'Chaussures', '18', '11', '198'),
(4, '205', 'Pull', '52', '11', '572'),
(5, '215', 'Montre', '25', '25', '625'),
(6, '218', 'Veste', '21', '10', '210'),
(7, '220', 'Bracelet', '55', '8', '440');